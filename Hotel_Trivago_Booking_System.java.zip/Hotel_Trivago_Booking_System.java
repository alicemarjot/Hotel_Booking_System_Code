package hotel_trivago_booking_system;

import java.util.Scanner;

public class Hotel_Trivago_Booking_System {

    public static int total = 0;

    public static void main(String[] args) {
        Scanner Input = new Scanner(System.in);

        System.out.println("Welcome to...");
        System.out.println("Hotel?");
        System.out.println("Trivago.");
        System.out.println("");
       

        System.out.println("Room Types include: ");
        System.out.println("Single Room = 50");
        System.out.println("Double Room = 75");
        System.out.println("Family Room = 105");
        System.out.println("What room would you like? Please input the price: ");

        int roomChoice = Input.nextInt();
        if (roomChoice == 50) {
            System.out.println("You have chosen: Single Room");
            int newTotal = total + 50;
            

            System.out.println("Boards: ");
            System.out.println("Self-Catering = 0");
            System.out.println("Half-Board = 10");
            System.out.println("Full Board = 20");
            System.out.println("What board would you like? Please input the price");
            int board = Input.nextInt();

            if (board == 0) {
                System.out.println("You have chosen Self-Catering");
                int brandNewTotal = newTotal + board;
                System.out.println("");

                System.out.println("How many days would you like to stay for?");
                int numDays = Input.nextInt();
                int fullTotal = brandNewTotal * numDays;
                if (numDays > 7) {
                    int num1 = brandNewTotal * 7;
                    int num2 = (int) (((numDays - 7) * brandNewTotal) * 0.8);
                    System.out.println("Total Pay:" + (num1 + num2));
                }
                else{
                    System.out.println("Total pay:" + (numDays*brandNewTotal));
                }
            }

            if (board == 10) {
                System.out.println("You have chosen Half-Board");
                int brandNewTotal = newTotal + board;
                System.out.println("");
                System.out.println("How many days would you like to stay for?");
                int numDays = Input.nextInt();
                int fullTotal = brandNewTotal * numDays;
                if (numDays > 7) {
                    int num1 = brandNewTotal * 7;
                    int num2 = (int) (((numDays - 7) * brandNewTotal) * 0.8);
                    System.out.println("Total Pay:" + (num1 + num2));
                }
            }

            if (board == 20) {
                System.out.println("You have chosen Full Board");
                int brandNewTotal = newTotal + board;
                System.out.println("");
                System.out.println("How many days would you like to stay for?");
                int numDays = Input.nextInt();
                int fullTotal = brandNewTotal * numDays;
                if (numDays > 7) {
                    int num1 = brandNewTotal * 7;
                    int num2 = (int) (((numDays - 7) * brandNewTotal) * 0.8);
                    System.out.println("Total Pay:" + (num1 + num2));
                }
            }
        }

        if (roomChoice == 75) {
            System.out.println("You have chosen: Double Room");
            int newTotal = total + 75;
            System.out.println("");

            System.out.println("Boards: ");
            System.out.println("Self-Catering = 0");
            System.out.println("Half-Board = 10");
            System.out.println("Full Board = 20");
            System.out.println("What board would you like? Please input the price");
            int board = Input.nextInt();

            if (board == 0) {
                System.out.println("You have chosen Self-Catering");
                int brandNewTotal = newTotal + board;
                System.out.println("");
                System.out.println("How many days would you like to stay for?");
                int numDays = Input.nextInt();
                int fullTotal = brandNewTotal * numDays;
                if (numDays > 7) {
                    int num1 = brandNewTotal * 7;
                    int num2 = (int) (((numDays - 7) * brandNewTotal) * 0.8);
                    System.out.println("Total Pay:" + (num1 + num2));
                }
            }
            if (board == 10) {
                System.out.println("You have chosen Half-Board");
                int brandNewTotal = newTotal + board;
                System.out.println("");
                System.out.println("How many days would you like to stay for?");
                int numDays = Input.nextInt();
                int fullTotal = brandNewTotal * numDays;
                if (numDays > 7) {
                    int num1 = brandNewTotal * 7;
                    int num2 = (int) (((numDays - 7) * brandNewTotal) * 0.8);
                    System.out.println("Total Pay:" + (num1 + num2));
                }
            }

            if (board == 20) {
                System.out.println("You have chosen Full Board");
                int brandNewTotal = newTotal + board;
                System.out.println("");
                System.out.println("How many days would you like to stay for?");
                int numDays = Input.nextInt();
                int fullTotal = brandNewTotal * numDays;
                if (numDays > 7) {
                    int num1 = brandNewTotal * 7;
                    int num2 = (int) (((numDays - 7) * brandNewTotal) * 0.8);
                    System.out.println("Total Pay:" + (num1 + num2));
                }
            }
        }

        //FAMILY ROOM
        if (roomChoice == 105) {

            System.out.println("You have chosen: Family room");
            int newTotal = total + 105;

            System.out.println("Boards: ");
            System.out.println("Self-Catering = 0");
            System.out.println("Half-Board = 10");
            System.out.println("Full Board = 20");
            System.out.println("What board would you like? Please input the price");
            int board = Input.nextInt();

            //FAMILY ROOM SELFCATERING
            if (board == 0) {
                System.out.println("You have chosen Self-Catering");
                int brandNewTotal = newTotal + board;
                System.out.println("");
                System.out.println("How many days would you like to stay for?");
                int numDays = Input.nextInt();
                int fullTotal = brandNewTotal * numDays;
                if (numDays > 7) {
                    int num1 = brandNewTotal * 7;
                    int num2 = (int) (((numDays - 7) * brandNewTotal) * 0.8);
                    System.out.println("Total Pay:" + (num1 + num2));
                }
            }

            if (board == 10) {
                System.out.println("You have chosen Half-Board");
                int brandNewTotal = newTotal + board;
                System.out.println("");
                System.out.println("How many days would you like to stay for?");
                int numDays = Input.nextInt();
                int fullTotal = brandNewTotal * numDays;
                if (numDays > 7) {
                    int num1 = brandNewTotal * 7;
                    int num2 = (int) (((numDays - 7) * brandNewTotal) * 0.8);
                    System.out.println("Total Pay:" + (num1 + num2));
                }
            }

            if (board == 20) {
                System.out.println("You have chosen Full Board");
                int brandNewTotal = newTotal + board;
                System.out.println("");
                System.out.println("How many days would you like to stay for?");
                int numDays = Input.nextInt();
                int fullTotal = brandNewTotal * numDays;
                if (numDays > 7) {
                    int num1 = brandNewTotal * 7;
                    int num2 = (int) (((numDays - 7) * brandNewTotal) * 0.8);
                    System.out.println("Total Pay:" + (num1 + num2));
                }
            }
        }

    }
}
    

